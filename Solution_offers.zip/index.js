var mysql = require('mysql');

exports.helloWorld = (req, res) => {
  // Parse parameters from Dialogflow CX request
  var username = req.body.sessionInfo.parameters.customer_id;
  process.on('uncaught', function(err){
    console.log(err);
  });

  // Create a MySQL connection
  var connection = mysql.createConnection({
    socketPath: '/cloudsql/cb1929840a-1000389672-gc:asia-south1:yara6',
    user: 'root',
    password: 'root',
    database: 'yara6',
  });

  // Connect to the database
  connection.connect(function (err) {

    if (err) {

      console.error('Error connecting:' + err.stack);

      return;
    }

    console.log('Connected as id' + connection.threadId);
  });


  
  var query = `SELECT offers FROM solution_offers WHERE customer_id = '${username}'`;

  // Execute the query
  connection.query(query, function (error, results, fields) {
    if (error) {
      console.error(error);
      res.status(500).send('Internal Server Error');
    } else {
      
      if (results.length === 0) {
        res.status(200).send({
          "fulfillmentResponse": {
            "messages": [
              {
                "text": {
                  "text": [`customer with name ${username} not found. Can I help You with anything else?`],
                },
              },
            ],
          },
        });
      } else {

        const Offer = results[0].offers;
        res.status(200).send({
          "fulfillmentResponse": {
            "messages": [
              {
                "text": {
                  "text": [` ${Offer}. Is there anything else I can help you with?`],
                },
              },
            ],
          },
        });
      }
    }
connection.end();
    // Close the database connection
   
  });
};