const nodemailer = require('nodemailer');

exports.helloWorld = (req, res) => {
  try {

    // const ticketInfo = req.body.queryResult.parameters.ticketInfo;
    const useremail = req.body.sessionInfo.parameters.useremail;
    const paymentEmailMessage = generatePaymentProcessingEmail(useremail);

    helloWorld(useremail,paymentEmailMessage, (error, info) => {
      if (error) {
        console.error('Error sending email:', error);
        res.status(500).json({ error: 'Internal Server Error' });
      } else {
        const response = {
          "fulfillmentResponse": {
            "messages": [
              {
                "text": {
                  "text": ['Email has been sent to your mail id. Can I help you with something else?']
                }
              }
            ]
          }
        };
        res.status(200).json(response);
      }
    });
  } catch (error) {
    console.error('Error handling request:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};
function generatePaymentProcessingEmail(useremail) {
  const currentDate = new Date();
  const formattedDate = currentDate.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
 
  return `
    Subject: Payment Processing Notification
 
    Dear ${useremail},
 
    We hope this message finds you well. We have received your payment, and it is currently in processing. Here are the details:
 
    
    - Payment Date: ${formattedDate}
    - Payment Method: Net Banking
 
    Please be advised that it may take a short period for the payment to be fully processed. Once the processing is complete, you will receive a confirmation email.
 
    If you have any questions or concerns regarding this payment, feel free to reach out to our support team at yaracohort1@gmail.com.
 
    Thank you for choosing our services.
 
    Best regards,
    DEXTER.
  `;
}

function helloWorld(useremail, emailMessage, callback) {
  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'yaracohort1@gmail.com',
      pass: 'ajma yaxc xfjc swyf'
    }
  });

  const mailOptions = {
    from: 'yaracohort1@gmail.com',
    to: useremail,
    subject: 'Ticket Information',
    text: emailMessage
  };

  transporter.sendMail(mailOptions, (error, info) => {
    callback(error, info);
  });
}
