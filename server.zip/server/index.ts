import { configureStore } from '@reduxjs/toolkit';
import { ClientOptions, server } from '@prime/server';
import { createRootReducer } from 'src/store';
import { App } from 'src/App';

const store = configureStore({
  reducer: createRootReducer(),
});

const serverOptions: Partial<ClientOptions> = {
  ssr: false,
  store,

  authorizationType: 'client',
  enableAuthentication: true,

  clientApp: App,
  https: {
    cert: './server/certs/cert.pem',
    key: './server/certs/key.pem',
  },
};

server(serverOptions);
